#!/usr/bin/env python3

from .call_indirection import CallIndirection
