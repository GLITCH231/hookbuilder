# Support

For general questions, see the
[FAQ](https://github.com/ClaudiuGeorgiu/Obfuscapk/blob/master/docs/FAQ.md).

If you're having technical issues, visit the
[troubleshooting](https://github.com/ClaudiuGeorgiu/Obfuscapk/blob/master/docs/TROUBLESHOOTING.md)
page.

If you'd like to report an issue, suggest a feature or simply ask a question, please do
so on the [issues page](https://github.com/ClaudiuGeorgiu/Obfuscapk/issues).

If you *really* need to contact the developers directly, you can find an email address
in the git commit history (support requests via email will be ignored, please use
[issues](https://github.com/ClaudiuGeorgiu/Obfuscapk/issues)).
