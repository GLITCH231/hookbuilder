package com.xxx.zzz.aall.javaxlll.annotationlll.metann;


public enum Whenz {
    
    ALWAYS,
    
    UNKNOWN,
    
    MAYBE,
    
    NEVER;

}
