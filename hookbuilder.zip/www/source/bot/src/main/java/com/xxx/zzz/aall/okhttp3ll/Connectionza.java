
package com.xxx.zzz.aall.okhttp3ll;

import java.net.Socket;

import com.xxx.zzz.aall.javaxlll.annotationlll.Nullableq;


public interface Connectionza {

  Routeza route();


  Socket socket();


  @Nullableq
  Handshakeza handshake();


  Protocolza protocol();
}
