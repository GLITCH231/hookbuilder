
package com.xxx.zzz.aall.okhttp3ll.internalss.httpnn;

public interface UnrepeatableRequestBody {
}
