package com.xxx.zzz.aall.ioppp.socketlll.clientbb;


public interface Ackq {

    public void call(Object... args);

}

